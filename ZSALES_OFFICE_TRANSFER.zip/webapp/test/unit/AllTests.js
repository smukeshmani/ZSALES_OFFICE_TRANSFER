sap.ui.define([
	"Transfersalesoffice/ZSALSE_OFFICE_TRANSFER/test/unit/controller/View1.controller"
], function () {
	"use strict";
});