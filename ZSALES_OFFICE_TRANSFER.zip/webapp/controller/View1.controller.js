var msg = "";
var vehicle = "";
var allowRefresh = false;
var vehicleId = "";
var RequestId = "";
var ImageType = {};
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/ValidateException",
	"sap/m/MessageBox",
	"Transfersalesoffice/ZSALSE_OFFICE_TRANSFER/model/models",
	"sap/ui/core/ValueState",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, MessageToast, ValidateException, MessageBox, models, ValueState, ResourceModel, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("Transfersalesoffice.ZSALSE_OFFICE_TRANSFER.controller.View1", {
		onInit: function () {
			var oMessageManager, oView;
			//debugger;
			oView = this.getView();
			oMessageManager = sap.ui.getCore().getMessageManager();
			oView.setModel(oMessageManager.getMessageModel(), "message");

			var oData = {};
			var string = "";
			var complete_url = window.location.href;
			var pieces = complete_url.split("reqid");
			var langugae = complete_url.split("sap-language");
			// set i18n model on view
			if (langugae.length > 1) {
				string = langugae[1];
				string = string.substr(1, 2);
				if (string === "AR" || string === "ar") {
					sap.ui.getCore().getConfiguration().setLanguage("ar");
				} else {
					sap.ui.getCore().getConfiguration().setLanguage("en");
				}
				// if()
			}
			// sap.ui.getCore().getConfiguration().setLanguage("ar");

			const i18nModel = new ResourceModel({
				bundleName: "Transfersalesoffice.ZSALSE_OFFICE_TRANSFER.i18n.i18n"
			});
			this.getView().setModel(i18nModel, "i18n");
			const oBundle = this.getView().getModel("i18n").getResourceBundle();

			if (pieces.length > 1) {
				string = pieces[1];
				RequestId = string.substr(1, 20);
				oData = {
					VehicleDetVisible: false,
					LocationDetVisible: false,
					idfileCheckList: true,
					idfileDL: true,
					idfileMOT: true,
					idFrontUpload: true,
					idLeftUpload: true,
					idRightUpload: true,
					idBackUpload: true,
					readmode: false,
					VehicleVisible:false,
					displaymode: true
				};
				var oModel = this.getOwnerComponent().getModel("TranferFlt");
				var sPath = "/SOTSendApprovalSet(RequestId='" + RequestId + "')";
				var that = this;
				// that = this;
				var btnHandler = function (evt) {
					that.viewImage(evt);
				};

				oModel.read(sPath, {
					success: function (oData, response) {
						// //debugger;
						//var oModel3 = new sap.ui.model.json.JSONModel(oData);
						oView.byId("idempId").setValue(oData.Pernr);
						oView.byId("idRequest").setText(oData.RequestId);
						oView.byId("idEmpName").setText(oData.CreatedBy);
						oView.byId("idEmpVehicle").setValue(oData.VehicleId);
						oView.byId("idVehDescr").setText(oData.VehicleText);
						oView.byId("idVehPlate").setText(oData.VehiclePlant);
						that.vechileId = that.vehicle = oData.VehicleId;
						that.salesoffice = oData.TeanVehicleSoffLoc;
						oView.byId("idTransfer").setValue(oData.TranVehicleLocId);
						oView.byId("idtrancl").setValue(oData.TeanVehicleSoffLoc);
						oView.byId("idTransferTxt").setText(oData.TranVehicleLoc);
						oView.byId("idtransltxt").setText(oData.TranVehicleSoffLocDesc);
						oView.byId("idtrancc").setValue(oData.TranVehicleCcId);
						oView.byId("idtrancct").setText(oData.TranVehicleCc);
						oView.byId("idtranMp").setValue(oData.TranVehicleMaintPlantId);
						oView.byId("idtranMpt").setText(oData.TranVehicleMaintPlant);
						oView.byId("idtranp").setValue(oData.TranVehiclePlantId);
						oView.byId("idtranpt").setText(oData.TranVehiclePlant);
						
						oView.byId("idcurrsl").setText(oData.VehicleSoffLoc);
						oView.byId("idcurrslt").setText(oData.VehicleSoffLocDesc);
						oView.byId("idcurrcc").setText(oData.VehicleCc);
						oView.byId("idcurrMp").setText(oData.VehiclePlant);
						oView.byId("idcurrcl").setText(oData.VehicleLocId);
						
						//var dates = oData.CreatedOn.substr(6, 2) + "/" + oData.CreatedOn.substr(4, 2) + "/" + oData.CreatedOn.substr(0, 4);
						oView.byId("idRequestDate").setText(oData.CreatedOn);
						//var times = oData.CreatedOntime.substr(0, 2) + ":" + oData.CreatedOntime.substr(2, 2) + ":" + oData.CreatedOntime.substr(4, 2);
						oView.byId("idRequestTime").setText(oData.CreatedOntime);

						oView.byId("idRequestor").setText(oData.CreatedBy);
			
						if (that.vehicle === "") {
							var msg = oBundle.getText("msg14");
							sap.m.MessageToast.show(msg);
							oView.getModel("localModel").setProperty("/VehicleDetVisible", false);
						} else {
							oView.getModel("localModel").setProperty("/VehicleDetVisible", true);
						}
						
						if (that.salesoffice === "") {
							var msg = oBundle.getText("msg14");
							sap.m.MessageToast.show(msg);
							oView.getModel("localModel").setProperty("/LocationDetVisible", false);
						} else {
							oView.getModel("localModel").setProperty("/LocationDetVisible", true);
						}
						var oModelDoc = that.getOwnerComponent().getModel("ProcessDlt");

						var myFilter = new sap.ui.model.Filter("FleetId", sap.ui.model.FilterOperator.EQ, (that.vehicle));
						oModelDoc.read("/FleetReqDocumentsSet", {
							filters: [myFilter],
							success: function (oDataImages, response1) {
								debugger;
								var oDataImagesData = new sap.ui.model.json.JSONModel(oDataImages);
								// oDataImagesData.setData(oDataImages);
								that.getView().setModel(oDataImagesData, "imagesButton");
								var oPanelLeft = that.getView().byId("idFleetImagesLeft");
								var oPanelRight = that.getView().byId("idFleetImagesRight");
								var oPanelFront = that.getView().byId("idFleetImagesFront");
								var oPanelBack = that.getView().byId("idFleetImagesBack");
								var oImages = [];
								oImages = oDataImages.results;
								for (let i = 0; i < oImages.length; i++) {
									let image = oImages[i];
									let name = "";
									if (image.AwsFileName !== "") {
										name = image.Zdate.toLocaleDateString();
										// value: "/fleet/"+image.AwsFileName 
										let oButton = new sap.m.Button({
												id: image.AwsFileName,
												text: name,
												type: "Accept",
												press: btnHandler,
												customData: new sap.ui.core.CustomData({
													key: "AwsFilePath",
													value: image.AwsFilePath

												})
											})
											// oPanel.addContent(oButton);
										if (image.DocType === "RIM") {
											oPanelRight.addContent(oButton);
										} else if (image.DocType === "BIM") {
											oPanelBack.addContent(oButton);
										} else if (image.DocType === "LIM") {
											oPanelLeft.addContent(oButton);
										} else if (image.DocType === "FIM") {
											oPanelFront.addContent(oButton);
										}
									}
								}
							},
							error: function () {
								sap.m.MessageToast.show("No Data retreived");
							}
						});

						// }

						var oModelChecklist = that.getOwnerComponent().getModel("TranferFlt");
						var sPath = "/SOTChecklistPostSet(Zrecord='" + RequestId + "')";
						// var that = this;
						oModelChecklist.read(sPath, {
							success: function (oData, response) {
								var oLocalModelCk = new sap.ui.model.json.JSONModel(oData);
								oView.setModel(oLocalModelCk, "checklist");
							},
							error: function () {

								sap.m.MessageToast.show("No Data retreived");
								oView.getModel("localModel").setProperty("/VehicleDetVisible", false);
							}

						});
						// oView.byId("idVehDescr").setText(oData.EquDescr);

						//var osf = oView.byId("idReturn");
						//osf.setModel(oModel3);
						//var osf1 = oView.byId("LeaveApprover");
						//osf1.setModel(oModel3);
					},
					error: function () {

						sap.m.MessageToast.show("No Data retreived");
						oView.getModel("localModel").setProperty("/VehicleDetVisible", false);
					}

				});

			} else {
				oData = {
					VehicleDetVisible: false,
					LocationDetVisible: false,
					idfileCheckList: true,
					idfileDL: true,
					idfileMOT: true,
					idFrontUpload: true,
					idLeftUpload: true,
					idRightUpload: true,
					idBackUpload: true,
					readmode: true,
					displaymode: false
				};
			}

			this.oLocalModel = new sap.ui.model.json.JSONModel(oData);
			oView.setModel(this.oLocalModel, "localModel");
			this.filenameLicense = {};
			this.filetypeLicense = {};

			//this.getView().byId("idtoempidLabel").setEnabled(false);

			var oJsonModel = models.createJsonModel("/model/viewdata.json");
			this.getView().setModel(oJsonModel);

			//set json models
			//  var oJsonData = models.createJsonModel("fleetreturn/GBCReturnNew/model/viewdata.json");
		},

		viewImage: function (evt) {
			var obtn = evt.getSource();
			//now you have access to the respective button
			var customData = obtn.getCustomData()[0].getValue();
			// sap.m.MessageToast.show("button Clicked:" + customData)
			if (!this.displayContent) {
				this.displayContent = sap.ui.xmlfragment("Transfersalesoffice.ZSALSE_OFFICE_TRANSFER.fragments.filepreview", this);
				this.getView().addDependent(this.displayContent);
			}
			sap.ui.getCore().byId("idPdfViewer").setVisible(false);
			sap.ui.getCore().byId("image").setVisible(true);
			sap.ui.getCore().byId("image").setSrc(customData);
			this.displayContent.open();

		},
		onValueHelpSLocSearchCust: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("SalesOffice", FilterOperator.Contains, sValue);
			//var oFilter2 = new Filter("Name", FilterOperator.Contains, sValue);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		onValueHelpSalLocRequestCust: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			if (!this._valueHelpLocDialog) {
				this._valueHelpLocDialog = sap.ui.xmlfragment(
					"Transfersalesoffice.ZSALSE_OFFICE_TRANSFER.fragments.ValueHelpSalLocationDialog",
					this
				);
				this.getView().addDependent(this._valueHelpLocDialog);
			}

			var oBinding = this._valueHelpLocDialog.getBinding("items");
			if (oBinding) {
				oBinding.filter([
					new sap.ui.model.Filter("SalesOffice",
						sap.ui.model.FilterOperator.Contains,
						sInputValue)
				]);
			}

			this._valueHelpLocDialog.open(sInputValue);
		},
		onValueHelpSLocCloseCust: function (oEvent) {

			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			this.byId("idtrancl").setValue(oSelectedItem.getTitle());
			var so = oSelectedItem.getTitle();
			if (so === "") {
				this.getView().byId("idtrancl").setValueState(sap.ui.core.ValueState.Error);
				//this._wizard.invalidateStep(this.byId("idCustomerDet"));
			} else {
				this.getView().byId("idtrancl").setValueState(sap.ui.core.ValueState.None);

			}
		},
		onValueHelpLocSearchCust: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("LocationId", FilterOperator.Contains, sValue);
			//var oFilter2 = new Filter("Name", FilterOperator.Contains, sValue);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		onValueHelpLocRequestCust: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			if (!this._valueHelpLocDialog) {
				this._valueHelpLocDialog = sap.ui.xmlfragment(
					"Transfersalesoffice.ZSALSE_OFFICE_TRANSFER.fragments.ValueHelpLocationDialog",
					this
				);
				this.getView().addDependent(this._valueHelpLocDialog);
			}

			var oBinding = this._valueHelpLocDialog.getBinding("items");
			if (oBinding) {
				oBinding.filter([
					new sap.ui.model.Filter("LocationId",
						sap.ui.model.FilterOperator.Contains,
						sInputValue)
				]);
			}

			this._valueHelpLocDialog.open(sInputValue);
		},
		onValueHelpLocCloseCust: function (oEvent) {

			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			this.byId("idTransfer").setValue(oSelectedItem.getTitle());
			var so = oSelectedItem.getTitle();
			if (so === "") {
				this.getView().byId("idTransfer").setValueState(sap.ui.core.ValueState.Error);
				//this._wizard.invalidateStep(this.byId("idCustomerDet"));
			} else {
				this.getView().byId("idTransfer").setValueState(sap.ui.core.ValueState.None);

			}
		},
		onValueHelpSearchCust: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("VechileID", FilterOperator.Contains, sValue);
			//var oFilter2 = new Filter("Name", FilterOperator.Contains, sValue);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		onValueHelpRequestCust: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			if (!this._valueHelpDialogCust) {
				this._valueHelpDialogCust = sap.ui.xmlfragment(
					"Transfersalesoffice.ZSALSE_OFFICE_TRANSFER.fragments.ValueHelpDialog",
					this
				);
				this.getView().addDependent(this._valueHelpDialogCust);
			}

			var oBinding = this._valueHelpDialogCust.getBinding("items");
			if (oBinding) {
				oBinding.filter([
					new sap.ui.model.Filter("VechileID",
						sap.ui.model.FilterOperator.Contains,
						sInputValue)
				]);
			}

			this._valueHelpDialogCust.open(sInputValue);
		},
		onValueHelpCloseCust: function (oEvent) {

			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			this.byId("idEmpVehicle").setValue(oSelectedItem.getTitle());
			this.byId("idVehPlate").setText(oSelectedItem.getDescription());

			var so = oSelectedItem.getTitle();
			if (so === "") {
				this.getView().byId("idEmpVehicle").setValueState(sap.ui.core.ValueState.Error);
				//this._wizard.invalidateStep(this.byId("idCustomerDet"));
			} else {
				this.getView().byId("idEmpVehicle").setValueState(sap.ui.core.ValueState.None);

			}
		},

		OnSalessubmit: function (oEvent) {

			var SalesOffice = this.getView().byId("idtrancl").getValue().toString().toUpperCase();
			var that = this;
			// var that = this;
			var btnHandler = function (evt) {
				that.viewImage(evt);
			};
			var oModel = this.getView().getModel("TranferFlt");
			var sPath = "/SOTSalesOfficeSet(SalesOffice='" + SalesOffice + "')";
			oModel.read(sPath, {
				success: function (oData2, response2) {
					if (oData2 !== null && (oData2.SalesOffice !== null && oData2.SalesOffice !== "")) {
						debugger;
						that.getView().byId("idtrancl").setValue(oData2.SalesOffice);
						that.getView().byId("idtransltxt").setText(oData2.SalesOfficeDec);
						that.getView().byId("idtrancc").setValue(oData2.CostCenter);
						that.getView().byId("idtrancct").setText(oData2.CostCenterDec);
						that.getView().byId("idTransfer").setValue(oData2.LocationId);
						that.getView().byId("idTransferTxt").setText(oData2.LocationText);
						that.getView().byId("idtranp").setValue(oData2.Plant);
						that.getView().byId("idtranpt").setText(oData2.PlantDec);
						that.getView().byId("idtranMp").setValue(oData2.MaintPlant);
						that.getView().byId("idtranMpt").setText(oData2.MaintPlantDec);
						
						that.getView().getModel("localModel").setProperty("/LocationDetVisible", true);

					} else {
						sap.m.MessageToast.show("No Data retreived");
						that.getView().byId("idtransltxt").setText("");
						that.getView().byId("idtrancc").setValue("");
						that.getView().byId("idtrancct").setText("");
						that.getView().byId("idTransfer").setValue("");
						that.getView().byId("idTransferTxt").setText("");
						that.getView().byId("idtranp").setValue("");
						that.getView().byId("idtranpt").setText("");
						that.getView().byId("idtranMp").setValue("");
						that.getView().byId("idtranMpt").setText("");
						that.getView().getModel(
							"localModel").setProperty("/LocationDetVisible", false);
					}
				},
				error: function () {
					sap.m.MessageToast.show("No Data retreived");
					that.getView().byId("idtransltxt").setText("");
					that.getView().byId("idtrancc").setValue("");
					that.getView().byId("idtrancct").setText("");
					that.getView().byId("idTransfer").setValue("");
					that.getView().byId("idTransferTxt").setText("");
					that.getView().byId("idtranp").setValue("");
					that.getView().byId("idtranpt").setText("");
					that.getView().byId("idtranMp").setValue("");
					that.getView().byId("idtranMpt").setText("");
					that.getView().getModel(
						"localModel").setProperty("/LocationDetVisible", false);
				}
			});
		},
		onLocationSubmit: function (oEvent) {
			var LocationId = this.getView().byId("idTransfer").getValue().toString().toUpperCase();
			var that = this;
			// var that = this;
			var btnHandler = function (evt) {
				that.viewImage(evt);
			};
			var oModel = this.getView().getModel("TranferFlt");
			var sPath = "/TransferLocationDetailsSet(TranLocation='" + LocationId + "')";
			oModel.read(sPath, {
				success: function (oData2, response2) {
					if (oData2 !== null && (oData2.TranLocation !== null && oData2.TranLocation !== "")) {
						debugger;
						that.getView().byId("idtrancc").setValue(oData2.TranCostCenter);
						that.getView().byId("idtrancct").setText(oData2.TranCostCenterTxt);
						that.getView().byId("idTransfer").setValue(oData2.TranLocation);
						that.getView().byId("idTransferTxt").setText(oData2.TranLocationTxt);
						that.getView().byId("idtranp").setValue(oData2.TranPlant);
						that.getView().byId("idtranpt").setText(oData2.TranPlantTxt);
						that.getView().byId("idtranMp").setValue(oData2.TranMaintPlant);
						that.getView().byId("idtranMpt").setText(oData2.TranMaintPlantTxt);

					} else {
						sap.m.MessageToast.show("No Data retreived");

						that.getView().byId("idtrancc").setValue("");
						that.getView().byId("idtrancct").setText("");
						that.getView().byId("idTransferTxt").setText("");
						that.getView().byId("idtranp").setValue("");
						that.getView().byId("idtranpt").setText("");
						that.getView().byId("idtranMp").setValue("");
						that.getView().byId("idtranMpt").setText("");

					}
				},
				error: function () {
					sap.m.MessageToast.show("No Data retreived");
					that.getView().byId("idtrancc").setValue("");
					that.getView().byId("idtrancct").setText("");
					that.getView().byId("idTransferTxt").setText("");
					that.getView().byId("idtranp").setValue("");
					that.getView().byId("idtranpt").setText("");
					that.getView().byId("idtranMp").setValue("");
					that.getView().byId("idtranMpt").setText("");
				}
			});
		},
		onPlantChange: function (oEvent) {
			var plantId = oEvent.getSource().getValue();
			var that = this;
			// var that = this;
			var btnHandler = function (evt) {
				that.viewImage(evt);
			};
			var oModel = this.getView().getModel("TranferFlt");
			var sPath = "/SOTMaintPlantSet(Plant='" + plantId + "')";
			oModel.read(sPath, {
				success: function (oData2, response2) {
					if (oData2 !== null && (oData2.Plant !== null && oData2.Plant !== "")) {
						debugger;
						that.getView().byId("idtranp").setValue(oData2.Plant);
						that.getView().byId("idtranpt").setText(oData2.PlantTxt);
					} else {
						sap.m.MessageToast.show("No Data retreived");
						that.getView().byId("idtranp").setValue("");
						that.getView().byId("idtranpt").setText("");
					}
				},
				error: function () {
					sap.m.MessageToast.show("No Data retreived");

					that.getView().byId("idtranp").setValue("");
					that.getView().byId("idtranpt").setText("");
			
				}
			});
		},
		onMaintPlantChange: function (oEvent) {
			var plantId = oEvent.getSource().getValue();
			var that = this;
			// var that = this;
			var btnHandler = function (evt) {
				that.viewImage(evt);
			};
			var oModel = this.getView().getModel("TranferFlt");
			var sPath = "/SOTMaintPlantSet(Plant='" + plantId + "')";
			oModel.read(sPath, {
				success: function (oData2, response2) {
					if (oData2 !== null && (oData2.Plant !== null && oData2.Plant !== "")) {
						debugger;
						that.getView().byId("idtranMp").setValue(oData2.Plant);
						that.getView().byId("idtranMpt").setText(oData2.PlantTxt);
					} else {
						sap.m.MessageToast.show("No Data retreived");
						that.getView().byId("idtranMp").setValue("");
						that.getView().byId("idtranMpt").setText("");
					}
				},
				error: function () {
					sap.m.MessageToast.show("No Data retreived");

					that.getView().byId("idtranMp").setValue("");
					that.getView().byId("idtranMpt").setText("");
			
				}
			});
		},
		onCCSubmit: function (oEvent) {
			var CostCenter = this.getView().byId("idtrancc").getValue().toString().toUpperCase();
			var that = this;
			// var that = this;
			var btnHandler = function (evt) {
				that.viewImage(evt);
			};
			var oModel = this.getView().getModel("TranferFlt");
			var sPath = "/SOTCostCenterSet(CostCenter='" + CostCenter + "')";
			oModel.read(sPath, {
				success: function (oData2, response2) {
					if (oData2 !== null && (oData2.CostCenter !== null && oData2.CostCenter !== "")) {
						debugger;
						that.getView().byId("idtrancc").setValue(oData2.CostCenter);
						that.getView().byId("idtrancct").setText(oData2.CostCenterDec);
					} else {
						sap.m.MessageToast.show("No Data retreived");
						that.getView().byId("idtrancct").setText("");
					}
				},
				error: function () {
					sap.m.MessageToast.show("No Data retreived");
					that.getView().byId("idtrancct").setText("");
				}
			});
		},
		onSubmit: function (oEvent) {

			// //debugger;
			that = this;
			var btnHandler = function (evt) {
				that.viewImage(evt);
			};
			const oBundle = this.getView().getModel("i18n").getResourceBundle();
			this.Pernr = this.getView().byId("idempId").getValue();
			var vehicleKey = this.getView().byId("idEmpVehicle").getValue();
			if (this.Pernr !== "" || vehicleKey !== "") {
				this.getView().byId("idempId").setValueState("None");
				this.getView().byId("idEmpName").setText("");
				var that = this;

				var oModel = this.getOwnerComponent().getModel("TranferFlt");
				var sPath = "/EmployeeVehicleDetailsSet(Pernr='" + this.Pernr + "',VehicleKey='" + vehicleKey + "')";
				this.getView().byId('idFrontUpload').setValueState(sap.ui.core.ValueState.Error);
				this.getView().byId('idLeftUpload').setValueState(sap.ui.core.ValueState.Error);
				this.getView().byId('idRightUpload').setValueState(sap.ui.core.ValueState.Error);
				this.getView().byId('idBackUpload').setValueState(sap.ui.core.ValueState.Error);
				oModel.read(sPath, {
					success: function (oData, response) {
						debugger;
						//var oModel3 = new sap.ui.model.json.JSONModel(oData);
						that.getView().byId("idempId").setValue(oData.Pernr);
						that.getView().byId("idEmpName").setText(oData.NameEn);
						that.getView().byId("idEmpVehicle").setValue(oData.VehicleKey);
						that.getView().byId("idVehPlate").setText(oData.Plate);
						that.getView().byId("idcurrsl").setText(oData.CurrSalesLocation);
						that.getView().byId("idcurrslt").setText(oData.CurrSalesLocationTxt);
						that.getView().byId("idcurrcc").setText(oData.CurrCostCenter);
						that.getView().byId("idcurrcct").setText(oData.CurrCostCenterTxt);
						that.getView().byId("idcurrMp").setText(oData.CurrMaintPlant);
						that.getView().byId("idcurrMpt").setText(oData.CurrMaintPlantTxt);
						that.getView().byId("idcurrcl").setText(oData.CurrLocation);
						that.CCtext = oData.CurrLocationTxt;
						that.vechileId = that.vehicle = oData.VehicleKey;
						that.empid = oData.Pernr;
						if (that.empid === "") {
							this.getView().byId("idempId").setValue("");
							this.getView().byId("idEmpName").setText("");
						}
						if (that.vehicle === "") {
							var msg = oBundle.getText("msg14");
							sap.m.MessageToast.show(msg);
							// sap.m.MessageToast.show("No Vehicle Details available for the employee");
							that.getView().getModel("localModel").setProperty("/VehicleVisible", true);
							that.getView().getModel("localModel").setProperty("/VehicleDetVisible", false);
						} else {
							that.getView().getModel("localModel").setProperty("/VehicleVisible", false);
							that.getView().getModel("localModel").setProperty("/VehicleDetVisible", true);
						}
						that.getView().byId("idVehDescr").setText(oData.VehicleName);
						var oModels = that.getOwnerComponent().getModel("ProcessDlt");

						var myFilter = new sap.ui.model.Filter("FleetId", sap.ui.model.FilterOperator.EQ, (that.vehicle));
						oModels.read("/FleetReqDocumentsSet", {
							filters: [myFilter],
							success: function (oDataImages, response1) {
								debugger;
								var oDataImagesData = new sap.ui.model.json.JSONModel(oDataImages);
								// oDataImagesData.setData(oDataImages);
								that.getView().setModel(oDataImagesData, "imagesButton");
								var oPanelLeft = that.getView().byId("idFleetImagesLeft");
								var oPanelRight = that.getView().byId("idFleetImagesRight");
								var oPanelFront = that.getView().byId("idFleetImagesFront");
								var oPanelBack = that.getView().byId("idFleetImagesBack");
								var oImages = [];
								oImages = oDataImages.results;
								// var back, left, right, front;
								// back = left = right = front = 1;
								for (let i = 0; i < oImages.length; i++) {
									let image = oImages[i];
									let name = "";
									if (image.AwsFileName !== "") {
										// if (image.DocType === "RIM") {
										// 	name = "Right-" + right;
										// 	right++;
										// } else if (image.DocType === "BIM") {
										// 	name = "Back-" + back;
										// 	back++;
										// } else if (image.DocType === "LIM") {
										// 	name = "Left-" + left;
										// 	left++;
										// } else if (image.DocType === "FIM") {
										// 	name = "Front-" + front;
										// 	front++;
										// }
										name = image.Zdate.toLocaleDateString();
										// value: "/fleet/"+image.AwsFileName 
										let oButton = new sap.m.Button({
												id: image.AwsFileName,
												text: name,
												type: "Accept",
												press: btnHandler,
												customData: new sap.ui.core.CustomData({
													key: "AwsFilePath",
													value: image.AwsFilePath

												})
											})
											// oPanel.addContent(oButton);
										if (image.DocType === "RIM") {
											oPanelRight.addContent(oButton);
										} else if (image.DocType === "BIM") {
											oPanelBack.addContent(oButton);
										} else if (image.DocType === "LIM") {
											oPanelLeft.addContent(oButton);
										} else if (image.DocType === "FIM") {
											oPanelFront.addContent(oButton);
										}
									}
								}
							},
							error: function () {
								sap.m.MessageToast.show("No Data retreived");
							}
						});

						//var osf = that.getView().byId("idReturn");
						//osf.setModel(oModel3);
						//var osf1 = that.getView().byId("LeaveApprover");
						//osf1.setModel(oModel3);
					},
					error: function () {

						sap.m.MessageToast.show("No Data retreived");
						that.getView().getModel("localModel").setProperty("/VehicleDetVisible", false);
					}

				});
			} else {
				// sap.m.MessageToast.show("");
				//	MessageBox.alert("Please enter Transferor employee ID");
				this.getView().byId("idempId").setValueState("Error");
				this.getView().byId("idempId").setValueStateText("Enter Transferor employee ID");
				this.getView().byId("idempId").setShowValueStateMessage(true);
				//this.getView().byId("idempId").setValueState("Please enter Transferor employee ID");
			}

		},
		openIshtimarahFile: function (oEvent) {

			var Zftype = 'ISH';
			this.openDocument(oEvent, Zftype, true);

		},
		openInsuranceFile: function (oEvent) {

			var Zftype = 'INS';
			this.openDocument(oEvent, Zftype, true);

		},
		openMOTCard: function (oEvent) {

			var Zftype = 'MOT';
			this.openDocument(oEvent, Zftype, true);

		},
		openMVPIDocument: function (oEvent) {

			var Zftype = 'MVPI';
			this.openDocument(oEvent, Zftype, true);

		},
		openCheckFile: function (oEvent) {
			var Zftype = 'CKL';
			this.openDocument(oEvent, Zftype, false);

		},
		openSASOCertificateFile: function (oEvent) {

			var Zftype = 'SASO';
			this.openDocument(oEvent, Zftype, true);

		},
		openDLFile: function (oEvent) {
			var Zftype = 'MOTD';
			this.openDocument(oEvent, Zftype, false);
		},
		openMOTCardDrvFile: function (oEvent) {
			var Zftype = 'DL';
			this.openDocument(oEvent, Zftype, false);
		},
		openRightBtn: function (oEvent) {
			var Zftype = 'RIM';
			this.openDocument(oEvent, Zftype, false);
		},
		openLeftBtn: function (oEvent) {
			var Zftype = 'LIM';
			this.openDocument(oEvent, Zftype, false);
		},
		openFrontBtn: function (oEvent) {
			var Zftype = 'FIM';
			this.openDocument(oEvent, Zftype, false);
		},
		openBackBtn: function (oEvent) {
			var Zftype = 'BIM';
			this.openDocument(oEvent, Zftype, false);
		},
		onPressBarCloseBtn: function (oEvent) {
			this.displayContent.close();
			this.fragOpen = undefined;
		},
		openDocument: function (oEvent, Zftype, fleet) {
			var vechId = this.getView().byId("idEmpVehicle").getValue();

			if (Zftype !== "") {
				//call SAP and get file data
				var that = this;
				var oModel;
				if (fleet === true) {
					oModel = that.getOwnerComponent().getModel("ProcessDlt");
					var sPath = "/FleetDocumentsSet(Equnr=" + "'" + vechId + "'" + ",DocType=" + "'" + Zftype + "'" + ",DocSeq='')";
				} else {
					oModel = that.getOwnerComponent().getModel("TranferFlt");
					var sPath = "/SOTReqDocumentsSet(RequestId=" + "'" + RequestId + "'" + ",DocType=" + "'" + Zftype + "'" + ")";

				}
				oModel.read(sPath, {
					success: function (oData, response) {
						//var oModel3 = new sap.ui.model.json.JSONModel(oData);
						var fMres = oData.Content;
						var fType = oData.Filetype;
						var fName = oData.Filename;
						if (oData.Content === "") {
							sap.m.MessageToast.show("No Fleet Document Available");
							return;
						}
						fMres = "data:" + fType + ";base64," + fMres;

						if (!that.displayContent) {
							that.displayContent = sap.ui.xmlfragment("Transfersalesoffice.ZSALSE_OFFICE_TRANSFER.fragments.filepreview", that);
							that.getView().addDependent(that.displayContent);
						}

						var splitTest = fType.split("/");
						var mimType = splitTest[0];
						var fType = fName.split(".");
						var fileType = fType[1];

						switch (mimType) {
						case 'image':
							sap.ui.getCore().byId("idPdfViewer").setVisible(false);
							sap.ui.getCore().byId("image").setVisible(true);
							sap.ui.getCore().byId("image").setSrc(fMres);
							break;
						default:
							sap.ui.getCore().byId("idPdfViewer").setVisible(true);
							sap.ui.getCore().byId("image").setVisible(false);
							var html = sap.ui.getCore().byId("idPdfViewer");
							html.setContent('<iframe src="' + fMres +
								'" embedded="true" frameborder="0" target="_top" width="2000px" height="2000px"></iframe>');
							break;
						}

						if (fileType !== "docx" && fileType !== "pub" && fileType !== "xls" && fileType !== "ppt" && fileType !== "doc" &&
							fileType !==
							"xlsx") {
							that.displayContent.open();
							that.fragOpen = true;
						}
						if (that.fragOpen === undefined) {
							window.open(fMres, "_self");
							fMres = fMres.replace("data:APPLICATION/WWI;base64,", "");
						}

						//	this.displayContent.open();

					},
					error: function () {

						sap.m.MessageToast.show("No Fleet Document Available");
					}

				});
			}

		},
		handleValueChange: function (oEvent) {
			// if(oEvent.getParameter('id'){
			this.getView().byId(oEvent.getParameter('id')).setValueState(sap.ui.core.ValueState.None);
			// }
			const oBundle = this.getView().getModel("i18n").getResourceBundle();
			const sMsg = oBundle.getText("msg7", [oEvent.getParameter("newValue")]);
			MessageToast.show(sMsg);
		},
		handleFile: function (oEvent) {
			//var oFileUploader  = this.getView().byId("idfileUploaderVAT");
			//var oFileSize =  oFileUploader.getSize();
			const oBundle = this.getView().getModel("i18n").getResourceBundle();
			const sMsg = oBundle.getText("msg6");
			sap.m.MessageToast.show(sMsg);
		},
		onComboxValidate(oEvent, id) {
			var idVal = this.getView().byId(id).getSelectedKey();
			var ids = this.getView().byId(id);

			if (idVal === "" || idVal === null) {
				const oBundle = this.getView().getModel("i18n").getResourceBundle();
				var text = oBundle.getText(id);

				var msg = oBundle.getText("msg5");
				var msg1 = oBundle.getText("msg4");
				ids.setValueState(ValueState.Error);
				ids.setValueStateText(text + " " + msg1);
				MessageBox.error(text + " " + msg, {
					actions: [sap.m.MessageBox.Action.CLOSE],

					onClose: function (sAction) {

					}
				});
				return;
			} else {
				ids.setValueState(ValueState.None);
			}
			return idVal;
		},
		onSelValueValidate(oEvent, id) {
			var idVal = this.getView().byId(id).getValue();
			var ids = this.getView().byId(id);

			if (idVal === "" || idVal === null) {
				const oBundle = this.getView().getModel("i18n").getResourceBundle();
				var text = oBundle.getText(id);

				var msg = oBundle.getText("msg5");
				var msg1 = oBundle.getText("msg4");
				ids.setValueState(ValueState.Error);
				ids.setValueStateText(text + " " + msg1);
				MessageBox.error(text + " " + msg, {
					actions: [sap.m.MessageBox.Action.CLOSE],

					onClose: function (sAction) {

					}
				});
				return;
			} else {
				ids.setValueState(ValueState.None);
			}
			return idVal;
		},
		onUploadDocument: function (oEvent, fileId, type, fleet) {
			var oFileUploader = this.getView().byId(fileId);
			var fileInput = oFileUploader.getDomRef().querySelector("input[type='file']");

			if (!fileInput || fileInput.files.length === 0) {
				sap.m.MessageToast.show("Please choose a file");
				return;
			}

			var file = fileInput.files[0];
			const oBundle = this.getView().getModel("i18n").getResourceBundle();
			var that = this;

			this.filenameLicense[type] = file.name;
			this.filetypeLicense[type] = file.type;
			this.getView().byId(fileId).setValueState(sap.ui.core.ValueState.None);

			var reader = new FileReader();

			reader.onload = function (e) {

				var vContent = e.currentTarget.result.replace("data:" + that.filetypeLicense[type] + ";base64,", "");
				var oDataModel;
				var payLoad = {};

				if (fleet === true) {
					payLoad = {
						"Equnr": that.vechileId,
						"DocType": type,
						"Content": vContent,
						"Filename": that.filenameLicense[type],
						"Filetype": that.filetypeLicense[type]
					};
					ImageType[type] = true;
					oDataModel = that.getOwnerComponent().getModel("ProcessDlt");
					oDataModel.create("/FleetDocumentsSet", payLoad, {
						success: function () {
							sap.m.MessageToast.show("Successfully Uploaded Document: " + fileId);
							if (allowRefresh === true && ImageType["BIM"] === true) {} else if (ImageType["BIM"] === true) {
								allowRefresh = true;
							}
						},
						error: function () {
							sap.m.MessageToast.show("Error in Uploading Document: " + fileId);
							if (allowRefresh === true && ImageType["BIM"] === true) {} else if (ImageType["BIM"] === true) {
								allowRefresh = true;
							}
						}
					});

				} else {
					payLoad = {
						"RequestId": RequestId,
						"DocType": type,
						"Content": vContent,
						"Filename": that.filenameLicense[type],
						"Filetype": that.filetypeLicense[type],
						"FleetId": that.vechileId
					};
					ImageType[type] = true;
					oDataModel = that.getOwnerComponent().getModel("TranferFlt");
					oDataModel.create("/SOTReqDocumentsSet", payLoad, {
						success: function () {
							const sMsg = oBundle.getText("msg10", [fileId]);
							sap.m.MessageToast.show(sMsg);
							if (allowRefresh === true && ImageType["BIM"] === true) {} else if (ImageType["BIM"] === true) {
								allowRefresh = true;
							}
						},
						error: function () {
							const sMsg = oBundle.getText("msg11", [fileId]);
							sap.m.MessageToast.show(sMsg);

							if (allowRefresh === true && ImageType["BIM"] === true) {} else if (ImageType["BIM"] === true) {
								allowRefresh = true;
							}
						}
					});
				}
			};

			reader.readAsDataURL(file);
		},

		onSign: function (oEvent) {
			var dataEnt = {
				Zrecord: RequestId,
				Status: 'X'
			};
			var oDataModel = this.getOwnerComponent().getModel("ReturnFlt");
			const oBundle = this.getView().getModel("i18n").getResourceBundle();
			oDataModel.create("/UpdateDigitialSignSet", dataEnt, {
				success: function (data) {
					const sMsg = oBundle.getText("msg3", [RequestId]);
					// msg = "Vehicle Transfer Request#" + " " + RequestId + " " + "Digital Signed Successfully";
					MessageBox.success(sMsg, {
						actions: [sap.m.MessageBox.Action.CLOSE],
						onClose: function (sAction) {
							window.history.go(-1);

						}
					});
				},
				error: function (oError) {

					const sMsg = oBundle.getText("msg2");
					MessageBox.error(sMsg, {
						actions: [sap.m.MessageBox.Action.CLOSE],
						onClose: function (sAction) {
							// location.reload();
						}
					});

				}
			});
		},

		onPress: function (oEvent) {
			debugger;
			var sUserId = "";

			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
				sUserId = sap.ushell.Container.getService("UserInfo").getId();
			} else {

				sUserId = "KAARFIORI";
			}

			const oBundle = this.getView().getModel("i18n").getResourceBundle();
			
			var idempId = this.onSelValueValidate(oEvent, "idempId");
				if (idempId === "" || idempId === undefined) {
					return;
				}
			var idEmpVehicle = this.onSelValueValidate(oEvent, "idEmpVehicle");
				if (idEmpVehicle === "" || idEmpVehicle === undefined) {
					return;
				}
			var idtrancl = this.onSelValueValidate(oEvent, "idtrancl");
				if (idtrancl === "" || idtrancl === undefined) {
					return;
				}
			var idTransfer = this.onSelValueValidate(oEvent, "idTransfer");
				if (idTransfer === "" || idTransfer === undefined) {
					return;
				}
			var idtrancc = this.onSelValueValidate(oEvent, "idtrancc");
				if (idtrancc === "" || idEmpVehicle === idtrancc) {
					return;
				}
				var idtranMp = this.onSelValueValidate(oEvent, "idtranMp");
				if (idtranMp === "" || idEmpVehicle === idtranMp) {
					return;
				}
				var idtranp = this.onSelValueValidate(oEvent, "idtranp");
				if (idtranp === "" || idEmpVehicle === idtranp) {
					return;
				}
			
			
			var iTransferor = this.getView().byId("idempId").getValue();
			var iEqunr = this.getView().byId("idEmpVehicle").getValue();
			var ivehicleTxt = this.getView().byId("idVehDescr").getText();
			var iTransferLoc = this.getView().byId("idTransfer").getValue();
			var iPlate = this.getView().byId("idVehPlate").getText();
			var iCSoffLoc = this.getView().byId("idcurrsl").getText();
			var iCSoffLocdesc = this.getView().byId("idcurrslt").getText();
			var icurCcp = this.getView().byId("idcurrcc").getText();
			var iCurrLoc = this.getView().byId("idcurrcl").getText();
			var iTransSoffLoc = this.getView().byId("idtrancl").getValue();
			var iTransSoffLocdesc = this.getView().byId("idtransltxt").getText()
			var iTransCC = this.getView().byId("idtrancc").getValue();
			var iTransLoc = this.getView().byId("idTransferTxt").getText();
			var iTransCCTxt = this.getView().byId("idtrancct").getText();
			var iTransMp = this.getView().byId("idtranMp").getValue();
			var iTransMpTxt = this.getView().byId("idtranMpt").getText();
			var iTransp = this.getView().byId("idtranp").getValue();
			var iTranspTxt = this.getView().byId("idtranpt").getText();

			var oDate = new Date();
			var sDate = oDate.toISOString().split("T")[0];

			if (iEqunr != "") {
				var front = this.getView().byId('idFrontUpload').getValueState();
				var left = this.getView().byId('idLeftUpload').getValueState();
				var right = this.getView().byId('idRightUpload').getValueState();
				var back = this.getView().byId('idBackUpload').getValueState();
				if (front === "Error" || left === "Error" || right === "Error" || back === "Error") {
					// msg1
					var msg = oBundle.getText("msg1");
					// sap.m.MessageToast.show(msg);
					MessageBox.error(msg, {
						actions: [sap.m.MessageBox.Action.CLOSE],

						onClose: function (sAction) {

						}
					});
					return;
				}
				var idRemark = this.getView().byId("idRemark").getValue();

				var idJack = this.onComboxValidate(oEvent, "idJack");
				if (idJack === "" || idJack === undefined) {
					return;
				}

				var idJackHandle = this.onComboxValidate(oEvent, "idJackHandle");
				if (idJackHandle === "" || idJackHandle === undefined) {
					return;
				}

				var idSpareTire = this.onComboxValidate(oEvent, "idSpareTire");
				if (idSpareTire === "" || idSpareTire === undefined) {
					return;
				}

				var idTriangle = this.onComboxValidate(oEvent, "idTriangle");
				if (idTriangle === "" || idTriangle === undefined) {
					return;
				}

				var idWheelSpanner = this.onComboxValidate(oEvent, "idWheelSpanner");
				if (idWheelSpanner === "" || idWheelSpanner === undefined) {
					return;
				}

				var idFireExtinguisher = this.onComboxValidate(oEvent, "idFireExtinguisher");
				if (idFireExtinguisher === "" || idFireExtinguisher === undefined) {
					return;
				}
				var idFuelCap = this.onComboxValidate(oEvent, "idFuelCap");
				if (idFuelCap === "" || idFuelCap === undefined) {
					return;
				}
				var idWindScreenScratch = this.onComboxValidate(oEvent, "idWindScreenScratch");
				if (idWindScreenScratch === "" || idWindScreenScratch === undefined) {
					return;
				}

				var idFrontTireCon = this.onComboxValidate(oEvent, "idFrontTireCon");
				if (idFrontTireCon === "" || idFrontTireCon === undefined) {
					return;
				}

				var idBackTireCon = this.onComboxValidate(oEvent, "idBackTireCon");
				if (idBackTireCon === "" || idBackTireCon === undefined) {
					return;
				}

				var idLightConditions = this.onComboxValidate(oEvent, "idLightConditions");
				if (idLightConditions === "" || idLightConditions === undefined) {
					return;
				}

				var idBodyScratch = this.onComboxValidate(oEvent, "idBodyScratch");
				if (idBodyScratch === "" || idBodyScratch === undefined) {
					return;
				}

				var idMirrorRearview = this.onComboxValidate(oEvent, "idMirrorRearview");
				if (idMirrorRearview === "" || idMirrorRearview === undefined) {
					return;
				}

				var idIndecation = this.onComboxValidate(oEvent, "idIndecation");
				if (idIndecation === "" || idIndecation === undefined) {
					return;
				}

				var idTailLight = this.onComboxValidate(oEvent, "idTailLight");
				if (idTailLight === "" || idTailLight === undefined) {
					return;
				}

				var idSideLight = this.onComboxValidate(oEvent, "idSideLight");
				if (idSideLight === "" || idSideLight === undefined) {
					return;
				}

				var idNumberPlate = this.onComboxValidate(oEvent, "idNumberPlate");
				if (idNumberPlate === "" || idNumberPlate === undefined) {
					return;
				}

				var idProtectionBars = this.onComboxValidate(oEvent, "idProtectionBars");
				if (idProtectionBars === "" || idProtectionBars === undefined) {
					return;
				}

				var idIstimarah = this.onComboxValidate(oEvent, "idIstimarah");
				if (idIstimarah === "" || idIstimarah === undefined) {
					return;
				}

				var idFAHS = this.onComboxValidate(oEvent, "idFAHS");
				if (idFAHS === "" || idFAHS === undefined) {
					return;
				}

				var idFirst = this.onComboxValidate(oEvent, "idFirst");
				if (idFirst === "" || idFirst === undefined) {
					return;
				}

				var idBoxBranding = this.onComboxValidate(oEvent, "idBoxBranding");
				if (idBoxBranding === "" || idBoxBranding === undefined) {
					return;
				}

				var idCabinBranding = this.onComboxValidate(oEvent, "idCabinBranding");
				if (idCabinBranding === "" || idCabinBranding === undefined) {
					return;
				}

				var idBackBranding = this.onComboxValidate(oEvent, "idBackBranding");
				if (idBackBranding === "" || idBackBranding === undefined) {
					return;
				}

				var idTruckCondition = this.onComboxValidate(oEvent, "idTruckCondition");
				if (idTruckCondition === "" || idTruckCondition === undefined) {
					return;
				}

				var idCabinCondition = this.onComboxValidate(oEvent, "idCabinCondition");
				if (idCabinCondition === "" || idCabinCondition === undefined) {
					return;
				}
				var Entry = {
					Pernr: iTransferor,
					CreatedBy: sUserId,
					CreatedOn: sDate,
					CreatedOntime: "",
					VehicleId: iEqunr,
					VehicleText: ivehicleTxt,
					VehicleNo: iEqunr,
					VehicleSoffLoc: iCSoffLoc,
					VehicleSoffLocDesc: iCSoffLocdesc,
					VehicleLoc: iCurrLoc,
					VehiclePlant: iPlate,
					VehicleLocId: "",
					VehicleCc: icurCcp,
					VehicleVendor: "",
					TeanVehicleSoffLoc: iTransSoffLoc,
					TranVehicleSoffLocDesc: iTransSoffLocdesc,
					TranVehicleLocId: iTransferLoc,
					TranVehicleLoc: iTransLoc,
					TranVehiclePlantId: iTransp,
					TranVehiclePlant: iTranspTxt,
					TranVehicleMaintPlantId: iTransMp,
					TranVehicleMaintPlant: iTransMpTxt,
					TranVehicleCcId: iTransCC,
					TranVehicleCc: iTransCCTxt,

				};

				var that = this;
				var checkList = {
					//Zrecord: data.Zrecord,

					Zjack: idJack,
					Zjackhandle: idJackHandle,
					Zsparetype: idSpareTire,
					Ztriangle: idTriangle,
					Zwheelspanner: idWheelSpanner,
					Zfireextinguisher: idFireExtinguisher,
					// Zairpipe: idAirPipe,
					// Zradio: idRadio,
					Zfuelcap: idFuelCap,
					// Zairscoop: idAirScoop,
					Zwindscreenscratch: idWindScreenScratch,
					Ztireconditions: idFrontTireCon,
					Zlightconditions: idLightConditions,
					Zbodyscratch: idBodyScratch,
					Zmirrorrearview: idMirrorRearview,
					Zindication: idIndecation,
					Ztaillight: idTailLight,
					Zsidelight: idSideLight,
					Znumberplate: idNumberPlate,
					Zprotectionbars: idProtectionBars,
					Zistimarah: idIstimarah,
					Zfahssticker: idFAHS,
					// Zmotcards: idMOT,
					// Zbrandingquality: idBrandingQuality,
					Zremarks: idRemark,
					// Zbreakdown
					// Zaccident
					// Zperiodicinspection
					// Zposted
					// Zerror
					//Zvehicleid: vehicle,
					Ztireconback: idBackTireCon,
					//ZfirstAid: idFirst,
					//ZboxBrand: idBoxBranding,
					//ZcabinBrand: idCabinBranding,
					//ZbacksideBrand: idBackBranding,
					//ZtruckCond: idTruckCondition,
					//ZCabinCond: idCabinCondition

				};

				var oModel = that.getOwnerComponent().getModel("TranferFlt");

				oModel.create("/SOTSendApprovalSet",
					Entry, {
						success: function (data) {
							// //debugger;
							if (data.Zduplicate == 'X') {

								//MessageBox.alert("A Transfer Request is already in process of approval, cannot submit new request");
								//location.reload();
								checkList.Zrecord = data.RequestId;

								// msg = "A Transfer Request#" + " " + "'" + data.Zrecord + "'" + " " +
								// 	"is already in process of approval.\n\ cannot submit a new request";
								msg = oBundle.getText("msg18", [data.RequestId]);
								MessageBox.error(msg, {
									actions: [sap.m.MessageBox.Action.CLOSE],
									//styleClass: bCompact ? "sapUiSizeCompact" : "",
									onClose: function (sAction) {
										setTimeout('', 5000);
										location.reload();
									}
								});

							} else if (data.Zduplicate != 'X') {
								// //debugger;
								RequestId = data.RequestId;
								checkList.Zrecord = data.RequestId;
								oModel.create("/SOTChecklistPostSet",
									checkList, {
										success: function (data) {
											var msg = oBundle.getText("msg12");
											sap.m.MessageToast.show(msg);
										},
										error: function () {
											var msg = oBundle.getText("msg13");
											sap.m.MessageToast.show(msg);
										}
									});
								that.onUploadDocument(oEvent, "idFrontUpload", "FIM", false);
								that.onUploadDocument(oEvent, "idLeftUpload", "LIM", false);
								that.onUploadDocument(oEvent, "idRightUpload", "RIM", false);
								that.onUploadDocument(oEvent, "idBackUpload", "BIM", false);

								const sMsg = oBundle.getText("msg3", [data.RequestId]);
								//	msg = "Vehicle Transfer Request#" + " " + + " " + "Submitted";
								MessageBox.success(sMsg, {
									actions: [sap.m.MessageBox.Action.CLOSE],
									//styleClass: bCompact ? "sapUiSizeCompact" : "",
									onClose: function (sAction) {
										// location.reload();
										if (allowRefresh === true) {
											//debugger;
											setTimeout('', 6000);
											location.reload();
										} else {
											//debugger;
											allowRefresh = true;
										}
									}
								});

								//location.reload();
							}
						},
						error: function (oError) {
							// //debugger;
							//	MessageBox.error("Error while submitting the transfer request. Please try again");
							var msg = oBundle.getText("msg2");
							MessageBox.error(msg, {
								actions: [sap.m.MessageBox.Action.CLOSE],
								//styleClass: bCompact ? "sapUiSizeCompact" : "",
								onClose: function (sAction) {
								//	location.reload();
								}
							});

						}

					});

			} else {
				var msg = oBundle.getText("msg9");
				MessageBox.error(msg, {
					actions: [sap.m.MessageBox.Action.CLOSE],
					//styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {
						//	location.reload();
					}
				});
			}
		}
	});
});